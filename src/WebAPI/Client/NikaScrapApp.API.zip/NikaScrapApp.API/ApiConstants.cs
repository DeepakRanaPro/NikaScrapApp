﻿namespace NikaScrapApp.API
{
    public class ApiConstants
    {
        public const string ServiceName = "feedbackservice";
        public const string FriendlyServiceName = "Feedback Service";
    }
}
